<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of BuscarController
 *
 * @author Laptop
 */
class Admin_IndexController extends CST_Controller_ActionAdmin {

    public function init() {
        parent::init();
        /* Initialize action controller here */
    }

    public function indexAction() {
                //$modelBusqueda = new Application_Model_Busqueda();
      $this->view->idBody = 'login-bg';
        
    }
    //put your code here
}

?>
