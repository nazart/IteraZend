<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Productos
 *
 * @author Laptop
 */

class Application_Model_TableBase_Producto extends CST_Db_Table{
    protected  $_name = "producto";
    protected  $_primary = "IdProducto";
}

?>
