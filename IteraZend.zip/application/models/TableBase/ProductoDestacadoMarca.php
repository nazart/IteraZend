<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Marca
 *
 * @author Laptop
 */
class Application_Model_TableBase_ProductoDestacadoMarca extends CST_Db_Table{
    protected  $_name = "productodestacadomarca";
    protected  $_primary = "IdProductosDestacados";

    //put your code here
}

?>
