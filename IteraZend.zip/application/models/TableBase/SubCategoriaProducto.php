<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SubCategoriaProducto
 *
 * @author Laptop
 */
class Application_Model_TableBase_SubCategoriaProducto extends CST_Db_Table{
    protected  $_name = "subcategoriaproducto";
    protected  $_primary = "IdSubCategoria";

}

