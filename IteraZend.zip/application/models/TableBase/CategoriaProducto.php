<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of SubCategoriaProducto
 *
 * @author Laptop
 */
class Application_Model_TableBase_CategoriaProducto extends CST_Db_Table{
    protected  $_name = "categoriaproducto";
    protected  $_primary = "IdCategoria";

}

