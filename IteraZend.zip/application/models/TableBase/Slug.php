<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DetalleSlug
 *
 * @author Laptop
 */
class Application_Model_TableBase_Slug extends CST_Db_Table{
    protected  $_name = "slug";
    protected  $_primary = "IdSlug";
    
    //put your code here
}

?>
