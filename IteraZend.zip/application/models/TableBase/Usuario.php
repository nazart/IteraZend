<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Usuario
 *
 * @author Laptop
 */
class Application_Model_TableBase_Usuario extends CST_Db_Table{
    protected  $_name = "usuario";
    protected  $_primary = "IdUsuario";
    
    //put your code here
}

?>
