<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Categoria
 *
 * @author Laptop
 */
class Application_Model_TableBase_ImagenProducto extends CST_Db_Table{
    protected  $_name = "imagenproducto";
    protected  $_primary = "IdImagenProducto";

}

?>
