<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DetalleSlug
 *
 * @author Laptop
 */
class Application_Model_TableBase_DetalleSlug extends CST_Db_Table{
    protected  $_name = "detalleslug";
    protected  $_primary = "IdDetalleSlug";
    
    //put your code here
}

?>
