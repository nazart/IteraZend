<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of Categoria
 *
 * @author Laptop
 */
class Application_Model_TableBase_CategoriaSoluciones extends CST_Db_Table{
    protected  $_name = "categoriasoluciones";
    protected  $_primary = "IdCategoriaSoluciones";

}

